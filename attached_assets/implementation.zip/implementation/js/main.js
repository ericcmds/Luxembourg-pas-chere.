// Luxembourg Pas Chere - Main JavaScript
// Handles interactive elements and user experience enhancements

document.addEventListener('DOMContentLoaded', function() {
  // Mobile navigation toggle
  initMobileNavigation();
  
  // Tab functionality
  initTabs();
  
  // Cookie consent
  initCookieConsent();
  
  // Lazy loading for images
  initLazyLoading();
});

/**
 * Initialize mobile navigation functionality
 */
function initMobileNavigation() {
  const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
  const mainNavigation = document.querySelector('.main-navigation');
  const headerActions = document.querySelector('.header-actions');
  
  if (mobileMenuToggle && mainNavigation && headerActions) {
    mobileMenuToggle.addEventListener('click', function() {
      // Toggle active class on the button
      this.classList.toggle('is-active');
      
      // Toggle active class on navigation and header actions
      mainNavigation.classList.toggle('is-active');
      headerActions.classList.toggle('is-active');
      
      // Update ARIA attributes
      const isExpanded = this.classList.contains('is-active');
      this.setAttribute('aria-expanded', isExpanded);
      mainNavigation.setAttribute('aria-hidden', !isExpanded);
      headerActions.setAttribute('aria-hidden', !isExpanded);
    });
  }
  
  // Close mobile menu when clicking outside
  document.addEventListener('click', function(event) {
    if (
      mobileMenuToggle && 
      mainNavigation && 
      mainNavigation.classList.contains('is-active') && 
      !event.target.closest('.mobile-menu-toggle') && 
      !event.target.closest('.main-navigation') &&
      !event.target.closest('.header-actions')
    ) {
      mobileMenuToggle.classList.remove('is-active');
      mainNavigation.classList.remove('is-active');
      headerActions.classList.remove('is-active');
      mobileMenuToggle.setAttribute('aria-expanded', false);
      mainNavigation.setAttribute('aria-hidden', true);
      headerActions.setAttribute('aria-hidden', true);
    }
  });
}

/**
 * Initialize tab functionality for all tab groups on the page
 */
function initTabs() {
  const tabGroups = document.querySelectorAll('.tabs-navigation');
  
  tabGroups.forEach(tabGroup => {
    const tabButtons = tabGroup.querySelectorAll('.tab-button');
    const tabContents = tabGroup.parentElement.querySelectorAll('.tab-content');
    
    if (tabButtons.length && tabContents.length) {
      tabButtons.forEach(button => {
        button.addEventListener('click', function() {
          // Remove active class from all buttons and contents
          tabButtons.forEach(btn => {
            btn.classList.remove('active');
            btn.setAttribute('aria-selected', 'false');
          });
          
          tabContents.forEach(content => {
            content.classList.remove('active');
            content.setAttribute('aria-hidden', 'true');
          });
          
          // Add active class to clicked button
          this.classList.add('active');
          this.setAttribute('aria-selected', 'true');
          
          // Show corresponding content
          const tabId = this.getAttribute('data-tab');
          const targetContent = document.getElementById(`tab-${tabId}`);
          
          if (targetContent) {
            targetContent.classList.add('active');
            targetContent.setAttribute('aria-hidden', 'false');
          }
        });
      });
    }
  });
}

/**
 * Initialize cookie consent functionality
 */
function initCookieConsent() {
  const cookieConsent = document.getElementById('cookie-consent');
  const acceptButton = document.querySelector('.btn-cookie-accept');
  const declineButton = document.querySelector('.btn-cookie-decline');
  
  // Check if cookie consent has already been given
  const consentGiven = localStorage.getItem('cookie-consent');
  
  if (cookieConsent && !consentGiven) {
    cookieConsent.style.display = 'block';
    
    if (acceptButton) {
      acceptButton.addEventListener('click', function() {
        localStorage.setItem('cookie-consent', 'accepted');
        cookieConsent.style.display = 'none';
        // Here you would typically enable all cookies and tracking
      });
    }
    
    if (declineButton) {
      declineButton.addEventListener('click', function() {
        localStorage.setItem('cookie-consent', 'declined');
        cookieConsent.style.display = 'none';
        // Here you would typically disable non-essential cookies
      });
    }
  } else if (cookieConsent) {
    cookieConsent.style.display = 'none';
  }
}

/**
 * Initialize lazy loading for images
 */
function initLazyLoading() {
  // Check if the browser supports IntersectionObserver
  if ('IntersectionObserver' in window) {
    const lazyImages = document.querySelectorAll('img[data-src]');
    
    const imageObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const img = entry.target;
          img.src = img.dataset.src;
          
          // If there's a data-srcset attribute, set that too
          if (img.dataset.srcset) {
            img.srcset = img.dataset.srcset;
          }
          
          img.removeAttribute('data-src');
          img.removeAttribute('data-srcset');
          imageObserver.unobserve(img);
        }
      });
    });
    
    lazyImages.forEach(img => {
      imageObserver.observe(img);
    });
  } else {
    // Fallback for browsers that don't support IntersectionObserver
    const lazyImages = document.querySelectorAll('img[data-src]');
    
    // Load all images immediately
    lazyImages.forEach(img => {
      img.src = img.dataset.src;
      
      if (img.dataset.srcset) {
        img.srcset = img.dataset.srcset;
      }
      
      img.removeAttribute('data-src');
      img.removeAttribute('data-srcset');
    });
  }
}

/**
 * Add smooth scrolling for anchor links
 */
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    const targetId = this.getAttribute('href');
    
    // Skip if it's just "#" or empty
    if (targetId === '#' || !targetId) return;
    
    const targetElement = document.querySelector(targetId);
    
    if (targetElement) {
      e.preventDefault();
      
      window.scrollTo({
        top: targetElement.offsetTop - 80, // Offset for fixed header
        behavior: 'smooth'
      });
    }
  });
});

/**
 * Form validation for newsletter subscription
 */
const newsletterForm = document.querySelector('.newsletter-form');

if (newsletterForm) {
  newsletterForm.addEventListener('submit', function(e) {
    e.preventDefault();
    
    const emailInput = this.querySelector('input[type="email"]');
    const email = emailInput.value.trim();
    
    if (validateEmail(email)) {
      // Here you would typically send the form data to your backend
      // For now, we'll just show a success message
      
      // Create success message
      const successMessage = document.createElement('p');
      successMessage.textContent = 'Thank you for subscribing!';
      successMessage.className = 'form-success';
      
      // Replace form with success message
      this.innerHTML = '';
      this.appendChild(successMessage);
    } else {
      // Show error message
      let errorMessage = this.querySelector('.form-error');
      
      if (!errorMessage) {
        errorMessage = document.createElement('p');
        errorMessage.className = 'form-error';
        this.appendChild(errorMessage);
      }
      
      errorMessage.textContent = 'Please enter a valid email address.';
      emailInput.focus();
    }
  });
}

/**
 * Validate email format
 * @param {string} email - The email to validate
 * @return {boolean} - Whether the email is valid
 */
function validateEmail(email) {
  const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(email);
}

/**
 * Add focus visible polyfill for better keyboard navigation
 */
function handleFirstTab(e) {
  if (e.keyCode === 9) { // Tab key
    document.body.classList.add('user-is-tabbing');
    window.removeEventListener('keydown', handleFirstTab);
  }
}

window.addEventListener('keydown', handleFirstTab);

/**
 * Add back-to-top button functionality
 */
const backToTopButton = document.createElement('button');
backToTopButton.innerHTML = '↑';
backToTopButton.className = 'back-to-top';
backToTopButton.setAttribute('aria-label', 'Back to top');
document.body.appendChild(backToTopButton);

// Show/hide back-to-top button based on scroll position
window.addEventListener('scroll', function() {
  if (window.pageYOffset > 300) {
    backToTopButton.classList.add('visible');
  } else {
    backToTopButton.classList.remove('visible');
  }
});

// Scroll to top when button is clicked
backToTopButton.addEventListener('click', function() {
  window.scrollTo({
    top: 0,
    behavior: 'smooth'
  });
});

/**
 * Add CSS for back-to-top button
 */
const style = document.createElement('style');
style.textContent = `
  .back-to-top {
    position: fixed;
    bottom: 20px;
    right: 20px;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background-color: var(--color-primary);
    color: white;
    font-size: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    opacity: 0;
    visibility: hidden;
    transition: opacity 0.3s, visibility 0.3s;
    z-index: 99;
  }
  
  .back-to-top.visible {
    opacity: 1;
    visibility: visible;
  }
  
  .form-error {
    color: var(--color-primary);
    font-size: 0.875rem;
    margin-top: 0.5rem;
  }
  
  .form-success {
    color: var(--color-accent);
    font-size: 0.875rem;
    margin-top: 0.5rem;
  }
  
  /* Focus styles for keyboard navigation */
  .user-is-tabbing *:focus {
    outline: 2px solid var(--color-secondary) !important;
    outline-offset: 2px !important;
  }
`;

document.head.appendChild(style);
