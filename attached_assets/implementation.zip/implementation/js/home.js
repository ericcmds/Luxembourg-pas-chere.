/**
 * Luxembourg Pas Chere - Home Page JavaScript
 * Handles content personalization, location-based features, and interactive elements
 */

document.addEventListener('DOMContentLoaded', function() {
  // Initialize tabs functionality
  initTabs();
  
  // Initialize content personalization
  initContentPersonalization();
  
  // Initialize location features
  initLocationFeatures();
  
  // Initialize animations
  initAnimations();
  
  // Initialize language handling
  initLanguageHandling();
});

/**
 * Initialize tabs functionality
 */
function initTabs() {
  const tabButtons = document.querySelectorAll('.tab-button');
  
  tabButtons.forEach(button => {
    button.addEventListener('click', function() {
      const tabId = this.getAttribute('data-tab');
      
      // Remove active class from all buttons and content
      document.querySelectorAll('.tab-button').forEach(btn => {
        btn.classList.remove('active');
      });
      
      document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
      });
      
      // Add active class to clicked button and corresponding content
      this.classList.add('active');
      document.getElementById(`tab-${tabId}`).classList.add('active');
    });
  });
}

/**
 * Initialize content personalization based on user behavior
 */
function initContentPersonalization() {
  // Check if user has visited before
  const isReturningUser = localStorage.getItem('returningUser');
  const lastVisit = localStorage.getItem('lastVisit');
  const visitCount = parseInt(localStorage.getItem('visitCount') || '0');
  
  // Update visit data
  localStorage.setItem('returningUser', 'true');
  localStorage.setItem('lastVisit', new Date().toISOString());
  localStorage.setItem('visitCount', (visitCount + 1).toString());
  
  // Track viewed categories
  let viewedCategories = JSON.parse(localStorage.getItem('viewedCategories') || '[]');
  
  // Get current page category
  const pageCategory = document.body.getAttribute('data-category');
  
  if (pageCategory && !viewedCategories.includes(pageCategory)) {
    viewedCategories.push(pageCategory);
    localStorage.setItem('viewedCategories', JSON.stringify(viewedCategories));
  }
  
  // Personalize content based on user data
  if (isReturningUser) {
    // Show returning user welcome
    const welcomeMessage = document.querySelector('.welcome-message');
    if (welcomeMessage) {
      welcomeMessage.textContent = 'Willkommen zurück bei Luxembourg Pas Chère!';
    }
    
    // Show recently viewed categories
    const recentCategoriesSection = document.querySelector('.recent-categories');
    if (recentCategoriesSection && viewedCategories.length > 0) {
      recentCategoriesSection.style.display = 'block';
      
      const categoryList = recentCategoriesSection.querySelector('.category-list');
      if (categoryList) {
        categoryList.innerHTML = '';
        
        // Show last 3 viewed categories
        viewedCategories.slice(-3).forEach(category => {
          const categoryLink = document.createElement('a');
          categoryLink.href = `/kategorien/${category}`;
          categoryLink.className = 'category-link';
          categoryLink.textContent = getCategoryDisplayName(category);
          
          categoryList.appendChild(categoryLink);
        });
      }
    }
    
    // Show new content since last visit
    if (lastVisit) {
      const lastVisitDate = new Date(lastVisit);
      const newContentSection = document.querySelector('.new-content');
      
      if (newContentSection) {
        // Find content items newer than last visit
        const contentItems = document.querySelectorAll('[data-published]');
        let newItemsCount = 0;
        
        contentItems.forEach(item => {
          const publishDate = new Date(item.getAttribute('data-published'));
          
          if (publishDate > lastVisitDate) {
            item.classList.add('new-since-last-visit');
            newItemsCount++;
          }
        });
        
        if (newItemsCount > 0) {
          newContentSection.style.display = 'block';
          const newContentCount = newContentSection.querySelector('.new-content-count');
          
          if (newContentCount) {
            newContentCount.textContent = newItemsCount.toString();
          }
        }
      }
    }
  } else {
    // Show first-time visitor welcome
    const firstTimeSection = document.querySelector('.first-time-visitor');
    if (firstTimeSection) {
      firstTimeSection.style.display = 'block';
    }
  }
}

/**
 * Initialize location-based features
 */
function initLocationFeatures() {
  // Handle location form submission
  const locationForm = document.querySelector('.location-form');
  if (locationForm) {
    locationForm.addEventListener('submit', function(e) {
      e.preventDefault();
      
      const locationInput = document.getElementById('location-input');
      if (locationInput && locationInput.value.trim()) {
        // Redirect to location page
        window.location.href = `/regionen/${slugify(locationInput.value.trim())}`;
      }
    });
  }
  
  // Handle current location button
  const currentLocationButton = document.querySelector('.use-current-location');
  if (currentLocationButton) {
    currentLocationButton.addEventListener('click', function() {
      if (navigator.geolocation) {
        // Show loading state
        this.classList.add('is-loading');
        this.disabled = true;
        
        navigator.geolocation.getCurrentPosition(
          function(position) {
            // Get user coordinates
            const userLat = position.coords.latitude;
            const userLng = position.coords.longitude;
            
            // Store user location in localStorage (with user consent)
            if (localStorage.getItem('locationConsent') === 'true') {
              localStorage.setItem('userLat', userLat);
              localStorage.setItem('userLng', userLng);
            }
            
            // Get nearest location (simulated)
            getNearestLocation(userLat, userLng)
              .then(nearestLocation => {
                // Redirect to location page
                window.location.href = `/regionen/${nearestLocation.slug}`;
              })
              .catch(error => {
                console.error('Error getting nearest location:', error);
                currentLocationButton.classList.remove('is-loading');
                currentLocationButton.disabled = false;
                alert('Konnte Ihren Standort nicht ermitteln. Bitte versuchen Sie es später erneut.');
              });
          },
          function(error) {
            console.error('Geolocation error:', error);
            currentLocationButton.classList.remove('is-loading');
            currentLocationButton.disabled = false;
            
            // Show appropriate error message
            let errorMessage = 'Konnte Ihren Standort nicht ermitteln. Bitte versuchen Sie es später erneut.';
            
            if (error.code === 1) {
              errorMessage = 'Standortzugriff wurde verweigert. Bitte erlauben Sie den Zugriff auf Ihren Standort in Ihren Browsereinstellungen.';
            } else if (error.code === 2) {
              errorMessage = 'Standort ist derzeit nicht verfügbar. Bitte versuchen Sie es später erneut.';
            } else if (error.code === 3) {
              errorMessage = 'Zeitüberschreitung bei der Standortermittlung. Bitte versuchen Sie es später erneut.';
            }
            
            alert(errorMessage);
          },
          {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 0
          }
        );
      } else {
        alert('Geolocation wird von Ihrem Browser nicht unterstützt.');
      }
    });
  }
  
  // Show location recommendations if user has previously shared location
  const userLat = localStorage.getItem('userLat');
  const userLng = localStorage.getItem('userLng');
  
  if (userLat && userLng && localStorage.getItem('locationConsent') === 'true') {
    getNearestLocation(parseFloat(userLat), parseFloat(userLng))
      .then(nearestLocation => {
        showLocationRecommendations(nearestLocation);
      })
      .catch(error => {
        console.error('Error getting location recommendations:', error);
      });
  }
}

/**
 * Get nearest location to user coordinates (simulated)
 * @param {number} lat - User latitude
 * @param {number} lng - User longitude
 * @return {Promise<Object>} - Promise resolving to nearest location object
 */
function getNearestLocation(lat, lng) {
  // In a real implementation, this would calculate the nearest location
  // For this example, we'll return a mock location
  return new Promise((resolve) => {
    // Simulate API delay
    setTimeout(() => {
      resolve({
        name: 'Luxemburg-Stadt',
        slug: 'luxemburg-stadt',
        lat: 49.6116547,
        lng: 6.1293599,
        distance: 2.3 // km
      });
    }, 1000);
  });
}

/**
 * Show location-based recommendations
 * @param {Object} location - Location object
 */
function showLocationRecommendations(location) {
  const recommendationsSection = document.querySelector('.location-recommendations');
  
  if (recommendationsSection) {
    // Update section title
    const sectionTitle = recommendationsSection.querySelector('.section-title');
    if (sectionTitle) {
      sectionTitle.textContent = `Empfehlungen in Ihrer Nähe: ${location.name}`;
    }
    
    // Show distance
    const distanceInfo = recommendationsSection.querySelector('.distance-info');
    if (distanceInfo) {
      distanceInfo.textContent = `${location.distance} km von Ihrem Standort entfernt`;
    }
    
    // Make section visible
    recommendationsSection.style.display = 'block';
    
    // Load location-specific offers
    const offersContainer = recommendationsSection.querySelector('.location-offers');
    if (offersContainer) {
      // Fetch offers for this location (simulated)
      getLocationOffers(location.name)
        .then(offers => {
          // Show first 3 offers
          const offersList = offers.slice(0, 3).map(offer => `
            <div class="offer-card">
              <div class="offer-content">
                <h3 class="offer-title">${offer.title}</h3>
                <p class="offer-location">${offer.address}</p>
                <p class="offer-discount">${offer.discount}</p>
                <a href="${offer.url}" class="offer-link">Angebot ansehen</a>
              </div>
            </div>
          `).join('');
          
          offersContainer.innerHTML = offersList;
        });
    }
  }
}

/**
 * Get offers data for a specific location (simulated)
 * @param {string} locationName - Name of the location
 * @return {Promise<Array>} - Promise resolving to array of offer objects
 */
function getLocationOffers(locationName) {
  // In a real implementation, this would fetch data from an API
  // For this example, we'll return mock data
  return new Promise((resolve) => {
    // Simulate API delay
    setTimeout(() => {
      // Mock data for Luxembourg City
      if (locationName === 'Luxemburg-Stadt') {
        resolve([
          {
            title: 'Bella Italia Restaurant',
            address: 'Avenue J.F. Kennedy 12, Kirchberg',
            discount: '30% OFF',
            url: '/angebote/bella-italia'
          },
          {
            title: 'Café de Paris',
            address: 'Rue de la Liberté 8, Gare',
            discount: '2-for-1 Breakfast',
            url: '/angebote/cafe-de-paris'
          },
          {
            title: 'City Museum',
            address: 'Rue du Saint-Esprit 14, Grund',
            discount: 'Free Entry on Sundays',
            url: '/angebote/city-museum'
          },
          {
            title: 'Boutique Chic',
            address: 'Grand-Rue 45, Centre',
            discount: '25% OFF',
            url: '/angebote/boutique-chic'
          }
        ]);
      } else {
        // Default empty array for other locations
        resolve([]);
      }
    }, 500);
  });
}

/**
 * Initialize animations
 */
function initAnimations() {
  // Check if user prefers reduced motion
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  
  if (!prefersReducedMotion) {
    // Add animation classes to elements
    const animatedSections = [
      '.hero-content',
      '.hero-image',
      '.categories-grid .category-card',
      '.region-content',
      '.guide-content',
      '.testimonial-card',
      '.about-content',
      '.location-finder',
      '.popular-locations'
    ];
    
    animatedSections.forEach((selector, index) => {
      const elements = document.querySelectorAll(selector);
      elements.forEach((el, i) => {
        el.classList.add('fade-in');
        
        // Add delay classes for staggered animations
        if (selector.includes('category-card') || selector.includes('testimonial-card')) {
          el.classList.add(`fade-in-delay-${i % 3 + 1}`);
        }
      });
    });
  }
}

/**
 * Initialize language handling
 */
function initLanguageHandling() {
  // Get current language from URL or localStorage
  const urlParams = new URLSearchParams(window.location.search);
  let currentLang = urlParams.get('lang') || localStorage.getItem('preferredLanguage') || 'de';
  
  // Set language in localStorage for future visits
  localStorage.setItem('preferredLanguage', currentLang);
  
  // Update UI to reflect current language
  const currentLangElement = document.querySelector('.current-language');
  if (currentLangElement) {
    currentLangElement.textContent = currentLang.toUpperCase();
  }
  
  // Mark active language in dropdown
  const langLinks = document.querySelectorAll('.language-dropdown a');
  langLinks.forEach(link => {
    link.classList.remove('active');
    if (link.getAttribute('hreflang') === currentLang) {
      link.classList.add('active');
    }
  });
  
  // Set html lang attribute
  document.documentElement.lang = currentLang;
  
  // Handle language selection
  langLinks.forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      
      const lang = this.getAttribute('hreflang');
      if (lang) {
        // Update URL with new language parameter
        const url = new URL(window.location);
        url.searchParams.set('lang', lang);
        
        // Store language preference
        localStorage.setItem('preferredLanguage', lang);
        
        // Navigate to URL with new language
        window.location.href = url.toString();
      }
    });
  });
}

/**
 * Helper function to convert string to slug
 * @param {string} text - Text to convert to slug
 * @return {string} - Slugified text
 */
function slugify(text) {
  return text
    .toString()
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, '-')
    .replace(/[^\w-]+/g, '')
    .replace(/--+/g, '-')
    .replace(/^-+|-+$/g, '');
}

/**
 * Helper function to get display name for category
 * @param {string} categorySlug - Category slug
 * @return {string} - Display name for category
 */
function getCategoryDisplayName(categorySlug) {
  const categoryMap = {
    'restaurants': 'Restaurants',
    'shopping': 'Shopping',
    'aktivitaten': 'Aktivitäten',
    'unterkunft': 'Unterkunft',
    'transport': 'Transport',
    'kultur': 'Kultur & Freizeit'
  };
  
  return categoryMap[categorySlug] || categorySlug;
}
