/**
 * Luxembourg Pas Chere - Critical JavaScript
 * Essential JavaScript for initial page functionality
 */

// Feature detection and browser support
(function() {
  // Remove no-js class
  document.documentElement.classList.remove('no-js');
  document.documentElement.classList.add('js');
  
  // Check WebP support
  const supportsWebP = localStorage.getItem('supportsWebP');
  if (supportsWebP === null) {
    const webpTest = new Image();
    webpTest.onload = function() {
      localStorage.setItem('supportsWebP', webpTest.width === 1);
      document.documentElement.classList.add('webp');
    };
    webpTest.onerror = function() {
      localStorage.setItem('supportsWebP', 'false');
      document.documentElement.classList.add('no-webp');
    };
    webpTest.src = 'data:image/webp;base64,UklGRiQAAABXRUJQVlA4IBgAAAAwAQCdASoBAAEAAwA0JaQAA3AA/vuUAAA=';
  } else if (supportsWebP === 'true') {
    document.documentElement.classList.add('webp');
  } else {
    document.documentElement.classList.add('no-webp');
  }
  
  // Check for reduced motion preference
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    document.documentElement.classList.add('reduced-motion');
  }
  
  // Initialize mobile navigation
  initMobileNavigation();
  
  // Initialize language selector
  initLanguageSelector();
  
  // Initialize cookie consent
  initCookieConsent();
})();

/**
 * Initialize mobile navigation
 */
function initMobileNavigation() {
  const menuToggle = document.querySelector('.mobile-menu-toggle');
  const mainNavigation = document.querySelector('.main-navigation');
  
  if (menuToggle && mainNavigation) {
    menuToggle.addEventListener('click', function() {
      const isExpanded = this.getAttribute('aria-expanded') === 'true';
      this.setAttribute('aria-expanded', !isExpanded);
      mainNavigation.classList.toggle('active');
      
      // Prevent body scrolling when menu is open
      document.body.classList.toggle('menu-open', !isExpanded);
    });
  }
}

/**
 * Initialize language selector
 */
function initLanguageSelector() {
  const languageSelector = document.querySelector('.language-selector button');
  const languageDropdown = document.querySelector('.language-dropdown');
  
  if (languageSelector && languageDropdown) {
    // Toggle dropdown on click
    languageSelector.addEventListener('click', function() {
      const isExpanded = this.getAttribute('aria-expanded') === 'true';
      this.setAttribute('aria-expanded', !isExpanded);
      languageDropdown.classList.toggle('active');
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function(event) {
      if (!event.target.closest('.language-selector')) {
        languageSelector.setAttribute('aria-expanded', 'false');
        languageDropdown.classList.remove('active');
      }
    });
    
    // Handle language selection
    const langLinks = languageDropdown.querySelectorAll('a');
    langLinks.forEach(link => {
      link.addEventListener('click', function(e) {
        e.preventDefault();
        
        const lang = this.getAttribute('hreflang');
        if (lang) {
          // Update URL with new language parameter
          const url = new URL(window.location);
          url.searchParams.set('lang', lang);
          
          // Store language preference
          localStorage.setItem('preferredLanguage', lang);
          
          // Navigate to URL with new language
          window.location.href = url.toString();
        }
      });
    });
  }
}

/**
 * Initialize cookie consent
 */
function initCookieConsent() {
  const cookieConsent = document.getElementById('cookie-consent');
  const acceptButton = document.querySelector('.btn-cookie-accept');
  const declineButton = document.querySelector('.btn-cookie-decline');
  
  if (cookieConsent && acceptButton && declineButton) {
    // Check if user has already made a choice
    const cookieChoice = localStorage.getItem('cookieConsent');
    
    if (!cookieChoice) {
      // Show cookie consent banner
      setTimeout(() => {
        cookieConsent.classList.add('active');
      }, 1000);
      
      // Handle accept button
      acceptButton.addEventListener('click', function() {
        localStorage.setItem('cookieConsent', 'accepted');
        localStorage.setItem('locationConsent', 'true');
        cookieConsent.classList.remove('active');
      });
      
      // Handle decline button
      declineButton.addEventListener('click', function() {
        localStorage.setItem('cookieConsent', 'declined');
        localStorage.setItem('locationConsent', 'false');
        cookieConsent.classList.remove('active');
      });
    }
  }
}

/**
 * Register service worker if supported
 */
if ('serviceWorker' in navigator) {
  window.addEventListener('load', function() {
    navigator.serviceWorker.register('/service-worker.js')
      .then(function(registration) {
        console.log('ServiceWorker registration successful with scope: ', registration.scope);
      })
      .catch(function(error) {
        console.log('ServiceWorker registration failed: ', error);
      });
  });
}
