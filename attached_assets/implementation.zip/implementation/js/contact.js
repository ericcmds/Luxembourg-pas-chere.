/**
 * Luxembourg Pas Chere - Contact Form JavaScript
 * Handles form validation, submission, and interactive elements
 */

document.addEventListener('DOMContentLoaded', function() {
  // Initialize contact form validation and submission
  initContactForm();
  
  // Initialize accordion functionality
  initAccordion();
  
  // Initialize animations
  initAnimations();
});

/**
 * Initialize contact form validation and submission
 */
function initContactForm() {
  const contactForm = document.getElementById('contact-form');
  
  if (!contactForm) return;
  
  // Form fields
  const nameInput = document.getElementById('name');
  const emailInput = document.getElementById('email');
  const phoneInput = document.getElementById('phone');
  const subjectInput = document.getElementById('subject');
  const messageInput = document.getElementById('message');
  const privacyCheckbox = document.getElementById('privacy');
  
  // Error message elements
  const nameError = document.getElementById('name-error');
  const emailError = document.getElementById('email-error');
  const phoneError = document.getElementById('phone-error');
  const subjectError = document.getElementById('subject-error');
  const messageError = document.getElementById('message-error');
  const privacyError = document.getElementById('privacy-error');
  
  // Form response element
  const formResponse = document.querySelector('.form-response');
  
  // Add input event listeners for real-time validation
  nameInput.addEventListener('input', () => validateField(nameInput, nameError, 'Bitte geben Sie Ihren Namen ein'));
  emailInput.addEventListener('input', () => validateEmail(emailInput, emailError));
  phoneInput.addEventListener('input', () => validatePhone(phoneInput, phoneError));
  subjectInput.addEventListener('input', () => validateField(subjectInput, subjectError, 'Bitte geben Sie einen Betreff ein'));
  messageInput.addEventListener('input', () => validateField(messageInput, messageError, 'Bitte geben Sie eine Nachricht ein'));
  privacyCheckbox.addEventListener('change', () => validateCheckbox(privacyCheckbox, privacyError, 'Sie müssen den Datenschutzbestimmungen zustimmen'));
  
  // Form submission
  contactForm.addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Validate all fields
    const isNameValid = validateField(nameInput, nameError, 'Bitte geben Sie Ihren Namen ein');
    const isEmailValid = validateEmail(emailInput, emailError);
    const isPhoneValid = validatePhone(phoneInput, phoneError);
    const isSubjectValid = validateField(subjectInput, subjectError, 'Bitte geben Sie einen Betreff ein');
    const isMessageValid = validateField(messageInput, messageError, 'Bitte geben Sie eine Nachricht ein');
    const isPrivacyValid = validateCheckbox(privacyCheckbox, privacyError, 'Sie müssen den Datenschutzbestimmungen zustimmen');
    
    // If all required fields are valid, submit the form
    if (isNameValid && isEmailValid && isSubjectValid && isMessageValid && isPrivacyValid && isPhoneValid) {
      // Show loading state
      const submitButton = contactForm.querySelector('button[type="submit"]');
      submitButton.classList.add('is-loading');
      submitButton.disabled = true;
      
      // Simulate form submission (replace with actual AJAX call)
      setTimeout(() => {
        // Hide loading state
        submitButton.classList.remove('is-loading');
        submitButton.disabled = false;
        
        // Show success message
        formResponse.textContent = 'Vielen Dank für Ihre Nachricht! Wir werden uns so schnell wie möglich bei Ihnen melden.';
        formResponse.className = 'form-response success';
        
        // Reset form
        contactForm.reset();
        
        // Clear validation states
        clearValidationState(nameInput, nameError);
        clearValidationState(emailInput, emailError);
        clearValidationState(phoneInput, phoneError);
        clearValidationState(subjectInput, subjectError);
        clearValidationState(messageInput, messageError);
        clearValidationState(privacyCheckbox, privacyError);
        
        // Scroll to response message
        formResponse.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        
        // Announce success to screen readers
        const successAnnouncement = document.createElement('div');
        successAnnouncement.setAttribute('aria-live', 'assertive');
        successAnnouncement.className = 'sr-only';
        successAnnouncement.textContent = 'Formular erfolgreich gesendet. Vielen Dank für Ihre Nachricht!';
        document.body.appendChild(successAnnouncement);
        
        // Remove announcement after it's been read
        setTimeout(() => {
          document.body.removeChild(successAnnouncement);
        }, 3000);
      }, 1500);
    } else {
      // Show error message
      formResponse.textContent = 'Bitte korrigieren Sie die markierten Felder und versuchen Sie es erneut.';
      formResponse.className = 'form-response error';
      
      // Focus the first invalid field
      const firstInvalid = contactForm.querySelector('.is-invalid');
      if (firstInvalid) {
        firstInvalid.focus();
      }
    }
  });
}

/**
 * Validate a required field
 * @param {HTMLElement} input - The input element to validate
 * @param {HTMLElement} errorElement - The element to display error messages
 * @param {string} errorMessage - The error message to display
 * @return {boolean} - Whether the field is valid
 */
function validateField(input, errorElement, errorMessage) {
  if (input.required && !input.value.trim()) {
    setInvalid(input, errorElement, errorMessage);
    return false;
  } else {
    setValid(input, errorElement);
    return true;
  }
}

/**
 * Validate email field
 * @param {HTMLElement} input - The email input element
 * @param {HTMLElement} errorElement - The element to display error messages
 * @return {boolean} - Whether the email is valid
 */
function validateEmail(input, errorElement) {
  if (!input.value.trim()) {
    setInvalid(input, errorElement, 'Bitte geben Sie Ihre E-Mail-Adresse ein');
    return false;
  } else if (!isValidEmail(input.value.trim())) {
    setInvalid(input, errorElement, 'Bitte geben Sie eine gültige E-Mail-Adresse ein');
    return false;
  } else {
    setValid(input, errorElement);
    return true;
  }
}

/**
 * Validate phone field
 * @param {HTMLElement} input - The phone input element
 * @param {HTMLElement} errorElement - The element to display error messages
 * @return {boolean} - Whether the phone is valid
 */
function validatePhone(input, errorElement) {
  if (input.value.trim() && !isValidPhone(input.value.trim())) {
    setInvalid(input, errorElement, 'Bitte geben Sie eine gültige Telefonnummer ein');
    return false;
  } else {
    setValid(input, errorElement);
    return true;
  }
}

/**
 * Validate checkbox field
 * @param {HTMLElement} input - The checkbox input element
 * @param {HTMLElement} errorElement - The element to display error messages
 * @param {string} errorMessage - The error message to display
 * @return {boolean} - Whether the checkbox is checked
 */
function validateCheckbox(input, errorElement, errorMessage) {
  if (input.required && !input.checked) {
    setInvalid(input, errorElement, errorMessage);
    return false;
  } else {
    setValid(input, errorElement);
    return true;
  }
}

/**
 * Set invalid state for an input
 * @param {HTMLElement} input - The input element
 * @param {HTMLElement} errorElement - The element to display error messages
 * @param {string} errorMessage - The error message to display
 */
function setInvalid(input, errorElement, errorMessage) {
  input.classList.add('is-invalid');
  input.setAttribute('aria-invalid', 'true');
  errorElement.textContent = errorMessage;
}

/**
 * Set valid state for an input
 * @param {HTMLElement} input - The input element
 * @param {HTMLElement} errorElement - The element to display error messages
 */
function setValid(input, errorElement) {
  input.classList.remove('is-invalid');
  input.setAttribute('aria-invalid', 'false');
  errorElement.textContent = '';
}

/**
 * Clear validation state for an input
 * @param {HTMLElement} input - The input element
 * @param {HTMLElement} errorElement - The element to display error messages
 */
function clearValidationState(input, errorElement) {
  input.classList.remove('is-invalid');
  input.removeAttribute('aria-invalid');
  errorElement.textContent = '';
}

/**
 * Check if email is valid
 * @param {string} email - The email to validate
 * @return {boolean} - Whether the email is valid
 */
function isValidEmail(email) {
  const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(email);
}

/**
 * Check if phone number is valid
 * @param {string} phone - The phone number to validate
 * @return {boolean} - Whether the phone number is valid
 */
function isValidPhone(phone) {
  const re = /^[+]?[(]?[0-9]{3}[)]?[-\s.]?[0-9]{3}[-\s.]?[0-9]{4,6}$/;
  return re.test(phone);
}

/**
 * Initialize accordion functionality
 */
function initAccordion() {
  const accordionItems = document.querySelectorAll('.accordion-item');
  
  accordionItems.forEach(item => {
    const button = item.querySelector('.accordion-button');
    const content = item.querySelector('.accordion-content');
    
    if (button && content) {
      button.addEventListener('click', function() {
        const isExpanded = this.getAttribute('aria-expanded') === 'true';
        
        // Close all accordion items
        accordionItems.forEach(otherItem => {
          const otherButton = otherItem.querySelector('.accordion-button');
          const otherContent = otherItem.querySelector('.accordion-content');
          
          if (otherItem !== item) {
            otherButton.setAttribute('aria-expanded', 'false');
            otherContent.classList.remove('active');
          }
        });
        
        // Toggle current accordion item
        this.setAttribute('aria-expanded', !isExpanded);
        content.classList.toggle('active');
        
        // Scroll into view if opening
        if (!isExpanded) {
          setTimeout(() => {
            content.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
          }, 300);
        }
      });
    }
  });
}

/**
 * Initialize animations
 */
function initAnimations() {
  // Check if user prefers reduced motion
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  
  if (prefersReducedMotion) {
    // Skip animations for users who prefer reduced motion
    document.querySelectorAll('.fade-in').forEach(el => {
      el.classList.add('is-visible');
    });
  } else {
    // Add fade-in class to elements
    const fadeElements = document.querySelectorAll('.contact-info, .contact-form, .section-header, .accordion');
    fadeElements.forEach(element => {
      element.classList.add('fade-in');
    });
    
    // Initialize intersection observer for animations
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, {
      threshold: 0.2,
      rootMargin: '0px 0px -100px 0px'
    });
    
    // Observe all animation elements
    document.querySelectorAll('.fade-in').forEach(el => {
      observer.observe(el);
    });
  }
  
  // Initialize back to top button
  initBackToTop();
}

/**
 * Initialize back to top button
 */
function initBackToTop() {
  const backToTopButton = document.querySelector('.back-to-top');
  
  if (!backToTopButton) return;
  
  // Show/hide back-to-top button based on scroll position
  window.addEventListener('scroll', function() {
    if (window.pageYOffset > 300) {
      backToTopButton.classList.add('visible');
    } else {
      backToTopButton.classList.remove('visible');
    }
  });
  
  // Scroll to top when button is clicked
  backToTopButton.addEventListener('click', function() {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  });
  
  // Handle keyboard interaction
  backToTopButton.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    }
  });
}
