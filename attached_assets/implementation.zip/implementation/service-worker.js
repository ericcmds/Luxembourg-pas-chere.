/**
 * Service Worker for Luxembourg Pas Chere Website
 * Provides offline support and caching for improved performance
 */

const CACHE_NAME = 'luxembourg-pas-chere-v1';
const URLS_TO_CACHE = [
  '/',
  '/index.html',
  '/css/critical.css',
  '/css/styles.css',
  '/css/home.css',
  '/js/critical.js',
  '/js/main.js',
  '/js/home.js',
  '/fonts/roboto-v20-latin-regular.woff2',
  '/fonts/roboto-v20-latin-700.woff2',
  '/images/hero-image.jpg',
  '/images/logo.svg',
  '/offline.html'
];

// Install event - cache assets
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        return cache.addAll(URLS_TO_CACHE);
      })
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.filter(cacheName => {
          return cacheName.startsWith('luxembourg-pas-chere-') && 
                 cacheName !== CACHE_NAME;
        }).map(cacheName => {
          return caches.delete(cacheName);
        })
      );
    })
  );
});

// Fetch event - serve from cache, fall back to network
self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // Cache hit - return response
        if (response) {
          return response;
        }
        
        // Clone the request
        const fetchRequest = event.request.clone();
        
        return fetch(fetchRequest).then(response => {
          // Check if valid response
          if (!response || response.status !== 200 || response.type !== 'basic') {
            return response;
          }
          
          // Clone the response
          const responseToCache = response.clone();
          
          // Cache the fetched response
          caches.open(CACHE_NAME)
            .then(cache => {
              cache.put(event.request, responseToCache);
            });
            
          return response;
        }).catch(() => {
          // If fetch fails (offline), show offline page for navigation requests
          if (event.request.mode === 'navigate') {
            return caches.match('/offline.html');
          }
        });
      })
  );
});

// Background sync for deferred operations
self.addEventListener('sync', event => {
  if (event.tag === 'newsletter-subscription') {
    event.waitUntil(syncNewsletterSubscriptions());
  }
});

// Handle background sync for newsletter subscriptions
function syncNewsletterSubscriptions() {
  return fetch('/api/sync-subscriptions')
    .then(response => response.json())
    .then(data => {
      console.log('Synced newsletter subscriptions:', data);
    })
    .catch(error => {
      console.error('Failed to sync newsletter subscriptions:', error);
    });
}
